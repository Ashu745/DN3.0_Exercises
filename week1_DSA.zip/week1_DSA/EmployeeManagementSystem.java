// Arrays are represented in memory as a contiguous block of elements, meaning all elements are stored next to each other. This layout allows for direct access to each element using its index, enabling constant-time access 𝑂(1)
// The address of any element can be quickly calculated using the base address of the array and the size of each element, which makes accessing elements very efficient.

// The primary advantages of arrays include their simplicity and fast access times. Since elements are stored in a continuous memory block, array indexing is straightforward and quick. Additionally, arrays are memory efficient when their size is known in advance and remains constant, as they avoid the overhead of dynamic resizing and extra pointers required in more complex data structures.


// Define Employee Class
class Employee {
    private String employeeId;
    private String name;
    private String position;
    private double salary;

    public Employee(String employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    // Getters and Setters
    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }
    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    @Override
    public String toString() {
        return "Employee [employeeId=" + employeeId + ", name=" + name + ", position=" + position + ", salary=" + salary + "]";
    }
}

public class EmployeeManagementSystem {
    //  Use Array to Store Employees
    private Employee[] employees = new Employee[100];
    private int size = 0;

    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size++] = employee;
        }
    }

    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public void deleteEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--size] = null;
                return;
            }
        }
    }

    // Analysis
    // Add: O(1) time complexity 
    // Search: O(n) time complexity
    // Traverse: O(n) time complexity
    // Delete: O(n) time complexity

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem();

        Employee emp1 = new Employee("E001", "John Doe", "Developer", 60000);
        Employee emp2 = new Employee("E002", "Jane Smith", "Manager", 80000);

        ems.addEmployee(emp1);
        ems.addEmployee(emp2);

        System.out.println("Employee Records:");
        ems.traverseEmployees();

        System.out.println("Searching for employee E001:");
        System.out.println(ems.searchEmployee("E001"));

        ems.deleteEmployee("E002");
        System.out.println("After deletion:");
        ems.traverseEmployees();
    }
}
