//  Efficient data structures and algorithms are crucial for handling large inventories because they ensure fast data retrieval, insertion, updating, and deletion. This improves the performance of the system, making it more responsive and capable of handling a high volume of transactions and queries.


//  Suitable data structures for inventory management:

// ArrayList: Provides fast access to elements by index, but slower insertions and deletions compared to linked structures.
// HashMap: Offers average O(1) time complexity for insertions, deletions, and lookups, making it suitable for inventory management where quick access to products by ID is required. 



import java.util.HashMap;
import java.util.Map;

public class InventoryManagementSystem {
    //  Define Product Class
    static class Product {
        private String productId;
        private String productName;
        private int quantity;
        private double price;

        public Product(String productId, String productName, int quantity, double price) {
            this.productId = productId;
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
        }

        // Getters and Setters
        public String getProductId() { return productId; }
        public void setProductId(String productId) { this.productId = productId; }
        public String getProductName() { return productName; }
        public void setProductName(String productName) { this.productName = productName; }
        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }
        public double getPrice() { return price; }
        public void setPrice(double price) { this.price = price; }

        @Override
        public String toString() {
            return "Product [productId=" + productId + ", productName=" + productName + ", quantity=" + quantity + ", price=" + price + "]";
        }
    }

    // Define Inventory Management with HashMap
    private Map<String, Product> inventory = new HashMap<>();

    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }

    public void updateProduct(String productId, int quantity, double price) {
        Product product = inventory.get(productId);
        if (product != null) {
            product.setQuantity(quantity);
            product.setPrice(price);
        }
    }

    public void deleteProduct(String productId) {
        inventory.remove(productId);
    }

    public Product getProduct(String productId) {
        return inventory.get(productId);
    }

    public void displayInventory() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    //  Analysis
    
    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();

        Product product1 = new Product("P001", "Laptop", 10, 999.99);
        Product product2 = new Product("P002", "Smartphone", 50, 499.99);

        ims.addProduct(product1);
        ims.addProduct(product2);

        ims.displayInventory();

        ims.updateProduct("P001", 15, 949.99);
        System.out.println("Updated Inventory:");
        ims.displayInventory();

        ims.deleteProduct("P002");
        System.out.println("After Deletion:");
        ims.displayInventory();
    }
}

