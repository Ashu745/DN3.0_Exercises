//  Linear Search Algorithm:

// Start at the beginning of the list.
// Compare each element with the target value.
// If the current element matches the target, return its index.
// Else, move to the next element.
// Repeat until you find the target or reach the end of the list.

// Compare the middle element with the target value.
// If the middle element matches the target, return its index.
// If the target is less than the middle element, move the high pointer to just before the middle.
// Else, move the low pointer to just after the middle.
// Repeat until you find the target or the interval is empty.

import java.util.Arrays;

class Book {
    private String bookId;
    private String title;
    private String author;

    public Book(String bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    // Getters and Setters
    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @Override
    public String toString() {
        return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + "]";
    }
}

public class LibraryManagementSystem {
    // Linear Search Implementation
    public static Book linearSearch(Book[] books, String targetTitle) {
        for (Book book : books) {
            if (book.getTitle().equals(targetTitle)) {
                return book;
            }
        }
        return null;
    }

    // Binary Search Implementation
    public static Book binarySearch(Book[] books, String targetTitle) {
        int left = 0, right = books.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = books[mid].getTitle().compareTo(targetTitle);
            
            if (cmp == 0) {
                return books[mid];
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Book[] books = {
            new Book("B1", "Introduction to Java", "John Doe"),
            new Book("B2", "Data Structures", "Jane Smith"),
            new Book("B3", "Algorithms", "Alice Johnson")
        };

        // Linear search
        System.out.println("Linear Search:");
        Book foundBook = linearSearch(books, "Data Structures");
        System.out.println(foundBook);

        // Binary search
        Arrays.sort(books, (b1, b2) -> b1.getTitle().compareTo(b2.getTitle()));
        System.out.println("Binary Search:");
        foundBook = binarySearch(books, "Data Structures");
        System.out.println(foundBook);
    }
}




// Time Complexity Comparison


// Linear Search:

// Time Complexity: 𝑂(𝑛)
// Scans each element one by one. Time complexity is linear, making it less efficient for large datasets.


// Binary Search:

// Time Complexity: 𝑂(log𝑛)
//  Repeatedly divides the search interval in half. Time complexity is logarithmic, making it much more efficient for large datasets compared to linear search.


// When to Use Each Algorithm:

// Linear Search:
// Use When:
// The dataset is small or unsorted.
// You need to search through an unordered collection.


// Binary Search:
// Use When:
// The dataset is large.
// The data is sorted or can be sorted.
// You need faster search performance compared to linear search.