//  Understand Asymptotic Notation
// Big O notation describes the performance or complexity of an algorithm in terms of the size of the input.
// - Linear search: O(n) time complexity
// - Binary search: O(log n) time complexity (requires sorted data)


import java.util.Arrays;

//  Define Product Class
class Product {
    private String productId;
    private String productName;
    private String category;

    public Product(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    public String getProductId() { return productId; }
    public String getProductName() { return productName; }
    public String getCategory() { return category; }
    public String toString() { return productId + ": " + productName + " (" + category + ")"; }
}

public class ECommerceSearchFunction {
    //  Linear Search 
    public static Product linearSearch(Product[] products, String targetName) {
        for (Product product : products) {
            if (product.getProductName().equals(targetName)) {
                return product;
            }
        }
        return null;
    }

    //  Binary Search 
    public static Product binarySearch(Product[] products, String targetName) {
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = products[mid].getProductName().compareTo(targetName);
            if (cmp == 0) {
                return products[mid];
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
       
        Product[] products = {
            new Product("P1", "Laptop", "Electronics"),
            new Product("P2", "Smartphone", "Electronics"),
            new Product("P3", "Book", "Books")
        };

        // Linear search
        System.out.println("Linear Search:");
        Product foundProduct = linearSearch(products, "Smartphone");
        System.out.println(foundProduct);

        // Binary search (Let sorted array)
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareTo(p2.getProductName()));
        System.out.println("Binary Search:");
        foundProduct = binarySearch(products, "Book");
        System.out.println(foundProduct);
    }
}
