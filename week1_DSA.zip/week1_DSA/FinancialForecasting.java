public class FinancialForecasting {
    //  Recursive Approach for Financial Forecasting
    public static double calculateFutureValue(double principal, double growthRate, int years) {
        if (years <= 0) {
            return principal;
        }
        return calculateFutureValue(principal * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        double principal = 1000.0;
        double growthRate = 0.05;
        int years = 10;

        double futureValue = calculateFutureValue(principal, growthRate, years);
        System.out.println("Future Value after " + years + " years: $" + futureValue);
    }
}

//Recursive Time Complexity

// The time complexity of the recursive calculateFutureValue method is O(n), where  n is the number of years. This is because the function makes one recursive call per year, leading to a linear number of function calls proportional to the number of years.

//Optimization Strategies
//1. Memoization:

//To optimize the recursive solution and avoid redundant calculations, you can use memoization. This involves storing results of intermediate computations so they don’t need to be recomputed. In this case, since the future value depends solely on the number of years and doesn’t involve overlapping subproblems, memoization might not be necessary. However, for more complex recursive problems, memoization can be useful.

//2. Iterative Approach:

//An iterative approach can often be more efficient than a recursive one. For this problem, you can use a loop to compute the future value, which avoids the overhead of recursive calls and is generally more efficient.