//Bubble Sort: This simple sorting algorithm repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order. This process is repeated until the list is sorted. Its time complexity is O(n*n), making it inefficient for large datasets.

// Insertion Sort: This algorithm builds the sorted list one item at a time by repeatedly picking the next item and inserting it into its correct position among the previously sorted items. It is efficient for small or partially sorted datasets, with a time complexity of O(n*n),in the worst case but O(n) ,in the best case if the list is already sorted.

// Quick Sort: Quick Sort uses a divide-and-conquer approach. It selects a 'pivot' element, partitions the array into elements less than and greater than the pivot, and recursively applies the same process to the sub-arrays. Its average time complexity is O(nlogn)  though it can degrade to  in the worst case with poor pivot choices.

// Merge Sort: Merge Sort also uses a divide-and-conquer strategy by recursively dividing the array into halves, sorting each half, and then merging the sorted halves to produce a sorted array. It consistently performs at O(nlogn) time complexity, making it more reliable than Quick Sort for large datasets, though it requires additional space for merging.


import java.util.Arrays;

// Define Order Class
class Order {
    private String orderId;
    private String customerName;
    private double totalPrice;

    public Order(String orderId, String customerName, double totalPrice) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.totalPrice = totalPrice;
    }

    public String getOrderId() { return orderId; }
    public String getCustomerName() { return customerName; }
    public double getTotalPrice() { return totalPrice; }

    public String toString() { return orderId + ": " + customerName + " - $" + totalPrice; }
}

public class SortingCustomerOrders {
    //  Bubble Sort Implementation
    public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    // Swap orders[j] and orders[j+1]
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    //Quick Sort 
    public static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }

    private static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() < pivot) {
                i++;
                
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
       
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

    public static void main(String[] args) {
       
        Order[] orders = {
            new Order("O001", "Alice", 250.50),
            new Order("O002", "Bob", 150.75),
            new Order("O003", "Charlie", 300.00)
        };

        // Bubble Sort
        Order[] bubbleSortedOrders = orders.clone();
        bubbleSort(bubbleSortedOrders);
        System.out.println("Bubble Sort:");
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }

        // Quick Sort
        Order[] quickSortedOrders = orders.clone();
        quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("Quick Sort:");
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}
