//Define Task Class
class Task {
    private String taskId;
    private String taskName;
    private String status;

    public Task(String taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    // Getters and Setters
    public String getTaskId() { return taskId; }
    public void setTaskId(String taskId) { this.taskId = taskId; }
    public String getTaskName() { return taskName; }
    public void setTaskName(String taskName) { this.taskName = taskName; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "Task [taskId=" + taskId + ", taskName=" + taskName + ", status=" + status + "]";
    }
}

// Implement Singly Linked List for Task Management
class Node {
    Task task;
    Node next;

    public Node(Task task) {
        this.task = task;
        this.next = null;
    }
}

class SinglyLinkedList {
    private Node head;

    public SinglyLinkedList() {
        head = null;
    }

    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    public Task searchTask(String taskId) {
        Node temp = head;
        while (temp != null) {
            if (temp.task.getTaskId().equals(taskId)) {
                return temp.task;
            }
            temp = temp.next;
        }
        return null;
    }

    public void traverseTasks() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.task);
            temp = temp.next;
        }
    }

    public void deleteTask(String taskId) {
        if (head == null) return;
        if (head.task.getTaskId().equals(taskId)) {
            head = head.next;
            return;
        }
        Node temp = head;
        while (temp.next != null && !temp.next.task.getTaskId().equals(taskId)) {
            temp = temp.next;
        }
        if (temp.next != null) {
            temp.next = temp.next.next;
        }
    }
}

public class TaskManagementSystem {
    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();

        Task task1 = new Task("T1", "Task 1", "Pending");
        Task task2 = new Task("T2", "Task 2", "Completed");

        taskList.addTask(task1);
        taskList.addTask(task2);

        System.out.println("Tasks:");
        taskList.traverseTasks();

        System.out.println("Searching for task T001:");
        System.out.println(taskList.searchTask("T001"));

        taskList.deleteTask("T002");
        System.out.println("After deletion:");
        taskList.traverseTasks();
    }
}



// Operations and Their Time Complexities:
// Addition (Insertion):
// At the beginning (head): 𝑂(1)
//  Directly modifying the head pointer.
// At the end (tail) or at a specific position: 𝑂(𝑛)
//  Requires traversing the list to find the end or insertion point, except if you maintain a tail pointer which makes end insertions 𝑂(1) Search:Finding a specific task by ID or name: 𝑂(𝑛)
//  Requires traversing the list from the head to find the task.
// Deletion:

// Removing a specific task (by ID or name): 𝑂(𝑛)
// Requires traversing the list to find and remove the task.
// Removing the first task: 𝑂(1)
//  Directly modifying the head pointer.
// Traversal:

// Iterating through all tasks: 𝑂(n)
// Each node is visited once to perform operations or display tasks.
// Advantages of Linked Lists Over Arrays for Dynamic Data:
// Dynamic Size:

// Linked Lists: Can easily grow or shrink in size by adding or removing nodes. This is beneficial when the number of tasks changes frequently, as linked lists handle such changes efficiently.
// Arrays: Have a fixed size upon creation. Resizing an array involves creating a new array and copying existing elements, which can be inefficient and cumbersome.
// Efficient Insertions/Deletions:

// Linked Lists: Insertions and deletions, particularly in the middle of the list, are more efficient as they only involve adjusting pointers. There is no need to shift elements, which is a significant advantage for dynamic data management.
// Arrays: Insertions and deletions, especially in the middle of the array, require shifting elements to maintain order, which can be time-consuming and inefficient.
// Memory Utilization:

// Linked Lists: Allocate memory for each node as needed, avoiding waste. Memory is used efficiently as nodes are added or removed dynamically.
// Arrays: May lead to unused space if the allocated size is larger than needed. Arrays can waste memory if not properly sized, and resizing can be expensive.
// No Need for Contiguous Memory:

// Linked Lists: Nodes are allocated independently, so there is no requirement for contiguous memory. This is advantageous in environments where memory allocation might be fragmented.
// Arrays: Require contiguous memory allocation, which can be a limitation if large blocks of contiguous memory are not available.
// In summary, for a task management system where tasks need to be added, deleted, and traversed efficiently, linked lists provide flexibility and efficiency in dynamic scenarios compared to arrays.